document.onreadystatechange = function() {
    if (document.readyState == "complete") {
        document.getElementsByClassName('button')[1].click()
    }
}
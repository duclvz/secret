document.onreadystatechange = function() {
    if (document.readyState == "complete") {
        if (document.querySelector('input#login-usr') != null && document.querySelector('input#login-pass') != null) {
        	$.getJSON(chrome.extension.getURL('account.json'), function(json) {
                document.querySelector('input#login-usr').value = json.account;
                document.querySelector('input#login-pass').value = json.password;
                if (!(json.account=='spotacc'||json.password=='spotpass'))
                	document.querySelector('button[type="submit"]').click()
            });
        }
        setTimeout(function() {
            if (document.querySelector('iframe[id^="browse-app-spotify:app:album"]') != null) {
                var iframeplay = document.querySelector('iframe[id^="browse-app-spotify:app:album"]')
                var playDoc = iframeplay.contentDocument || iframeplay.contentWindow.document;
                playDoc.querySelector('button.button-play').click()
                setTimeout(function() {
                    var iframeapp = document.querySelector('iframe#app-player')
                    var appDoc = iframeapp.contentDocument || iframeapp.contentWindow.document;
                    if(appDoc.querySelector('button#shuffle').getAttribute('class')!="active")
                    	appDoc.querySelector('button#shuffle').click()
                    if(appDoc.querySelector('button#repeat').getAttribute('class')!="active")
                    	appDoc.querySelector('button#repeat').click()
                }, 3000)
            }
        }, 15000);
    }
}